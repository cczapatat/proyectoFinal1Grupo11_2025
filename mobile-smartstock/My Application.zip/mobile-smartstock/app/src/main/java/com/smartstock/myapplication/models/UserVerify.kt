package com.smartstock.myapplication.models

data class UserVerify(
    val user_session_id:String,
    val user_id:String,
    val user_type: String

)