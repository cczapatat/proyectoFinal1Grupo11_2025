package com.smartstock.myapplication.models

data class User(
    val id:String = "",
    val user_id:String = "",
    val token: String = "",
    val name:String = "",
    val type:String = "",
    val phone: String = "",
    val email: String = "",
    val password: String = "",
    val zone: String = ""

)