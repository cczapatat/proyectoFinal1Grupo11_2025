package com.smartstock.myapplication.models

data class Devices (
    val id: Int,
    val name: String
)